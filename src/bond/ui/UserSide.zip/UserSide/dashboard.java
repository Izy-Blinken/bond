/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package bond.ui.UserSide;


public class dashboard extends javax.swing.JFrame {

    private void setupHover(javax.swing.JButton btn) {

        btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn.setForeground(java.awt.Color.WHITE);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setForeground(new java.awt.Color(150, 220, 180));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setForeground(java.awt.Color.WHITE);
            }
        });

        darkPanel.setBackground(new java.awt.Color(0, 0, 0, 150));
        darkPanel.setVisible(false);
        settingsPanel.setVisible(false);
    }

    public dashboard() {
        initComponents();

        this.setLocationRelativeTo(null);
        settingsPanel.setVisible(false);

        searchInput1.setOpaque(false);
        searchInput1.setBorder(null);
        searchInput1.setBackground(new java.awt.Color(0, 0, 0, 0));

        javax.swing.JButton[] buttons = {
            dashboardBtn,
            studOrgBtn,
            aboutBtn,
            settingsBtn
        };

        for (javax.swing.JButton btn : buttons) {
            setupHover(btn);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        searchInput = new javax.swing.JTextField();
        org1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        settingsPanel = new javax.swing.JPanel();
        settings = new javax.swing.JPanel();
        settingsLabel = new javax.swing.JLabel();
        exBtn = new javax.swing.JButton();
        registerAnOrgBtn = new javax.swing.JButton();
        loginAsOso = new javax.swing.JButton();
        darkPanel = new javax.swing.JPanel();
        searchInput1 = new javax.swing.JTextField();
        searchIcon = new javax.swing.JLabel();
        exploreBtn = new javax.swing.JButton();
        bondLabel = new javax.swing.JLabel();
        bondLongLabel = new javax.swing.JLabel();
        discover = new javax.swing.JLabel();
        track = new javax.swing.JLabel();
        university = new javax.swing.JLabel();
        settingsBtn = new javax.swing.JButton();
        aboutBtn = new javax.swing.JButton();
        studOrgBtn = new javax.swing.JButton();
        dashboardBtn = new javax.swing.JButton();
        navbar = new javax.swing.JLabel();
        dark = new javax.swing.JLabel();
        bsu = new javax.swing.JLabel();

        searchInput.setBackground(new java.awt.Color(0, 0, 0));
        searchInput.setFont(new java.awt.Font("Plus Jakarta Sans", 0, 14)); // NOI18N
        searchInput.setBorder(null);
        searchInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchInputActionPerformed(evt);
            }
        });

        org1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/poshed.png"))); // NOI18N
        org1.setBorder(null);
        org1.setBorderPainted(false);
        org1.setContentAreaFilled(false);
        org1.setFocusable(false);
        org1.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/poshedHover.png"))); // NOI18N
        org1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                org1ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        settingsPanel.setBackground(new java.awt.Color(255, 255, 255));
        settingsPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        settings.setBackground(new java.awt.Color(28, 94, 56));

        settingsLabel.setFont(new java.awt.Font("Plus Jakarta Sans", 1, 18)); // NOI18N
        settingsLabel.setForeground(new java.awt.Color(255, 255, 255));
        settingsLabel.setText("SETTINGS");

        exBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/exit_1.png"))); // NOI18N
        exBtn.setBorder(null);
        exBtn.setBorderPainted(false);
        exBtn.setContentAreaFilled(false);
        exBtn.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/exitHover_1.png"))); // NOI18N
        exBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout settingsLayout = new javax.swing.GroupLayout(settings);
        settings.setLayout(settingsLayout);
        settingsLayout.setHorizontalGroup(
            settingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(settingsLayout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(settingsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
                .addComponent(exBtn)
                .addGap(17, 17, 17))
        );
        settingsLayout.setVerticalGroup(
            settingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(settingsLayout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addGroup(settingsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, settingsLayout.createSequentialGroup()
                        .addComponent(exBtn)
                        .addGap(25, 25, 25))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, settingsLayout.createSequentialGroup()
                        .addComponent(settingsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))))
        );

        settingsPanel.add(settings, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 0, 250, -1));

        registerAnOrgBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/regOrg.png"))); // NOI18N
        registerAnOrgBtn.setBorder(null);
        registerAnOrgBtn.setBorderPainted(false);
        registerAnOrgBtn.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/regOrgHover.png"))); // NOI18N
        registerAnOrgBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerAnOrgBtnActionPerformed(evt);
            }
        });
        settingsPanel.add(registerAnOrgBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 210, 60));

        loginAsOso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/login.png"))); // NOI18N
        loginAsOso.setBorder(null);
        loginAsOso.setBorderPainted(false);
        loginAsOso.setContentAreaFilled(false);
        loginAsOso.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/lohinSettingshover.png"))); // NOI18N
        loginAsOso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginAsOsoActionPerformed(evt);
            }
        });
        settingsPanel.add(loginAsOso, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 210, -1));

        jPanel1.add(settingsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 0, 210, 600));

        darkPanel.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout darkPanelLayout = new javax.swing.GroupLayout(darkPanel);
        darkPanel.setLayout(darkPanelLayout);
        darkPanelLayout.setHorizontalGroup(
            darkPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 810, Short.MAX_VALUE)
        );
        darkPanelLayout.setVerticalGroup(
            darkPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );

        jPanel1.add(darkPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, 600));

        searchInput1.setBackground(new java.awt.Color(0, 0, 0));
        searchInput1.setFont(new java.awt.Font("Plus Jakarta Sans", 0, 14)); // NOI18N
        searchInput1.setBorder(null);
        searchInput1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchInput1ActionPerformed(evt);
            }
        });
        jPanel1.add(searchInput1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 30, 290, 30));

        searchIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/searchBar_1.png"))); // NOI18N
        jPanel1.add(searchIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 25, -1, -1));

        exploreBtn.setBackground(new java.awt.Color(28, 94, 56));
        exploreBtn.setFont(new java.awt.Font("Plus Jakarta Sans", 1, 14)); // NOI18N
        exploreBtn.setForeground(new java.awt.Color(255, 255, 255));
        exploreBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/exploreBtn.png"))); // NOI18N
        exploreBtn.setBorder(null);
        exploreBtn.setBorderPainted(false);
        exploreBtn.setContentAreaFilled(false);
        exploreBtn.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/exploreHover.png"))); // NOI18N
        exploreBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exploreBtnActionPerformed(evt);
            }
        });
        jPanel1.add(exploreBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 410, 240, 50));

        bondLabel.setFont(new java.awt.Font("Playfair Display", 1, 70)); // NOI18N
        bondLabel.setForeground(new java.awt.Color(255, 255, 255));
        bondLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bondLabel.setText("BOND");
        jPanel1.add(bondLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, 240, 90));

        bondLongLabel.setFont(new java.awt.Font("Plus Jakarta Sans", 1, 22)); // NOI18N
        bondLongLabel.setForeground(new java.awt.Color(255, 255, 255));
        bondLongLabel.setText("Bridging Organizations & Networks for Development");
        jPanel1.add(bondLongLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 640, 30));

        discover.setFont(new java.awt.Font("Plus Jakarta Sans", 1, 14)); // NOI18N
        discover.setForeground(new java.awt.Color(255, 255, 255));
        discover.setText("Discover  campus communities, explore student organizations,");
        jPanel1.add(discover, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, 460, -1));

        track.setFont(new java.awt.Font("Plus Jakarta Sans", 1, 14)); // NOI18N
        track.setForeground(new java.awt.Color(255, 255, 255));
        track.setText("track events, and stay connected with everything that shapes  ");
        jPanel1.add(track, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, -1, -1));

        university.setFont(new java.awt.Font("Plus Jakarta Sans", 1, 14)); // NOI18N
        university.setForeground(new java.awt.Color(255, 255, 255));
        university.setText("your university life.");
        jPanel1.add(university, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 360, 220, -1));

        settingsBtn.setBackground(new java.awt.Color(28, 94, 56));
        settingsBtn.setFont(new java.awt.Font("Plus Jakarta Sans", 1, 16)); // NOI18N
        settingsBtn.setForeground(new java.awt.Color(255, 255, 255));
        settingsBtn.setText("SETTINGS");
        settingsBtn.setBorder(null);
        settingsBtn.setBorderPainted(false);
        settingsBtn.setContentAreaFilled(false);
        settingsBtn.setFocusable(false);
        settingsBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                settingsBtnActionPerformed(evt);
            }
        });
        jPanel1.add(settingsBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 20, -1, 50));

        aboutBtn.setBackground(new java.awt.Color(28, 94, 56));
        aboutBtn.setFont(new java.awt.Font("Plus Jakarta Sans", 1, 16)); // NOI18N
        aboutBtn.setForeground(new java.awt.Color(255, 255, 255));
        aboutBtn.setText("ABOUT");
        aboutBtn.setBorder(null);
        aboutBtn.setBorderPainted(false);
        aboutBtn.setContentAreaFilled(false);
        aboutBtn.setFocusPainted(false);
        aboutBtn.setFocusable(false);
        aboutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutBtnActionPerformed(evt);
            }
        });
        jPanel1.add(aboutBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 20, -1, 50));

        studOrgBtn.setBackground(new java.awt.Color(28, 94, 56));
        studOrgBtn.setFont(new java.awt.Font("Plus Jakarta Sans", 1, 16)); // NOI18N
        studOrgBtn.setForeground(new java.awt.Color(255, 255, 255));
        studOrgBtn.setText("STUDENT ORGS");
        studOrgBtn.setBorder(null);
        studOrgBtn.setBorderPainted(false);
        studOrgBtn.setContentAreaFilled(false);
        studOrgBtn.setFocusPainted(false);
        studOrgBtn.setFocusable(false);
        studOrgBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studOrgBtnActionPerformed(evt);
            }
        });
        jPanel1.add(studOrgBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 20, -1, 50));

        dashboardBtn.setBackground(new java.awt.Color(28, 94, 56));
        dashboardBtn.setFont(new java.awt.Font("Plus Jakarta Sans", 1, 16)); // NOI18N
        dashboardBtn.setForeground(new java.awt.Color(255, 255, 255));
        dashboardBtn.setText("DASHBOARD");
        dashboardBtn.setBorder(null);
        dashboardBtn.setContentAreaFilled(false);
        dashboardBtn.setFocusPainted(false);
        dashboardBtn.setFocusable(false);
        dashboardBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashboardBtnActionPerformed(evt);
            }
        });
        jPanel1.add(dashboardBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 30, 170, 30));

        navbar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/navBar_1.png"))); // NOI18N
        jPanel1.add(navbar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, -1));

        dark.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/dark_1.png"))); // NOI18N
        jPanel1.add(dark, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 80, 1020, 520));

        bsu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bond/assets/UserImages/bulsu.png"))); // NOI18N
        jPanel1.add(bsu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 1000, 560));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void settingsBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_settingsBtnActionPerformed

        darkPanel.setVisible(true);
        settingsPanel.setVisible(true);
        settingsPanel.setLocation(750, 0);
    }//GEN-LAST:event_settingsBtnActionPerformed

    private void aboutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutBtnActionPerformed
        new about().setVisible(true);
        this.dispose();

    }//GEN-LAST:event_aboutBtnActionPerformed

    private void studOrgBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studOrgBtnActionPerformed
        new studOrg().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_studOrgBtnActionPerformed

    private void dashboardBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashboardBtnActionPerformed

    }//GEN-LAST:event_dashboardBtnActionPerformed

    private void exploreBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exploreBtnActionPerformed
        new studOrg().setVisible(true);
        this.dispose();

    }//GEN-LAST:event_exploreBtnActionPerformed

    private void searchInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchInputActionPerformed

    }//GEN-LAST:event_searchInputActionPerformed

    private void searchInput1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchInput1ActionPerformed

        String query = searchInput1.getText().trim();
        new studOrg().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_searchInput1ActionPerformed

    private void exBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exBtnActionPerformed
        darkPanel.setVisible(false);
        settingsPanel.setVisible(false);
    }//GEN-LAST:event_exBtnActionPerformed

    private void registerAnOrgBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerAnOrgBtnActionPerformed
     
        new registerAnOrg(this).setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_registerAnOrgBtnActionPerformed

    private void loginAsOsoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginAsOsoActionPerformed

        this.setVisible(false);
        loginChoices lc = new loginChoices(this);
        lc.setVisible(true);
    }//GEN-LAST:event_loginAsOsoActionPerformed

    private void org1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_org1ActionPerformed
        
        try {

            java.sql.Connection conn = bond.db.DBConnection.getConnection();
            java.sql.ResultSet rs = conn.prepareStatement(
                "SELECT org_id FROM organization WHERE is_featured = 1 ORDER BY org_id ASC LIMIT 1"
            ).executeQuery();

            if (rs.next()) {
                new studOrgClicked(rs.getInt("org_id")).setVisible(true);
                this.dispose();
            }

            conn.close();

        } catch (Exception ex) {
            System.out.println("Featured org error: " + ex.getMessage());
        }
    }//GEN-LAST:event_org1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(dashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new dashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton aboutBtn;
    private javax.swing.JLabel bondLabel;
    private javax.swing.JLabel bondLongLabel;
    private javax.swing.JLabel bsu;
    private javax.swing.JLabel dark;
    private javax.swing.JPanel darkPanel;
    private javax.swing.JButton dashboardBtn;
    private javax.swing.JLabel discover;
    private javax.swing.JButton exBtn;
    private javax.swing.JButton exploreBtn;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton loginAsOso;
    private javax.swing.JLabel navbar;
    private javax.swing.JButton org1;
    private javax.swing.JButton registerAnOrgBtn;
    private javax.swing.JLabel searchIcon;
    private javax.swing.JTextField searchInput;
    private javax.swing.JTextField searchInput1;
    private javax.swing.JPanel settings;
    private javax.swing.JButton settingsBtn;
    private javax.swing.JLabel settingsLabel;
    private javax.swing.JPanel settingsPanel;
    private javax.swing.JButton studOrgBtn;
    private javax.swing.JLabel track;
    private javax.swing.JLabel university;
    // End of variables declaration//GEN-END:variables
}
