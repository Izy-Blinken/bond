/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

import java.awt.image.BufferedImage;

/**
 *
 * @author ADMIN
 */
public class Tiles {
    
    public BufferedImage image;
    public boolean collision;
    
    public Tiles(BufferedImage image, boolean collision){
        this.image = image;
        this.collision = collision;
    }
    
}
